const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

let players = {};
let balls = [];
let scores = { blue: 0, red: 0 };
let finalWinner = null; 
let gameState = 'waiting';

function assignTeam() {
    const counts = { blue: 0, red: 0 };
    Object.values(players).forEach(p => {
        if (p.isSpectator) return;
        if (p.team === 'blue') counts.blue++;
        if (p.team === 'red') counts.red++;
    });
    return counts.blue <= counts.red ? 'blue' : 'red';
}

function adjustBallCount() {
    const activePlayerCount = Object.values(players).filter(p => !p.isSpectator).length;
    const targetBallCount = Math.max(1, Math.floor(activePlayerCount / 4));
    
    while (balls.length < targetBallCount) {
        balls.push({
            id: Math.random().toString(36).substr(2, 9),
            x: 700, 
            y: 300, 
            dx: (Math.random() - 0.5) * 5,
            dy: (Math.random() - 0.5) * 5,
            radius: 24,
            owner: "free",
            lastOwnerTeam: null,
            lastThrowerId: null,
            holdStartTime: null
        });
    }

    while (balls.length > targetBallCount) {
        const freeBallIndex = balls.findIndex(b => b.owner === "free");
        if (freeBallIndex !== -1) {
            balls.splice(freeBallIndex, 1);
        } else {
            break;
        }
    }
}

setInterval(() => {
    if (finalWinner) return;
    if (gameState !== 'playing') {
        io.emit('gameUpdate', { balls, players, scores, finalWinner, gameState });
        return;
    }

    const now = Date.now();

    balls.forEach(ball => {
        if (ball.owner === "free") {
            ball.x += ball.dx;
            ball.y += ball.dy;

            if (ball.x - ball.radius < 0 || ball.x + ball.radius > 1400) {
                ball.dx *= -1;
                ball.lastOwnerTeam = null;
                ball.lastThrowerId = null;
            }
            if (ball.y - ball.radius < 0 || ball.y + ball.radius > 600) {
                ball.dy *= -1;
                ball.lastOwnerTeam = null;
                ball.lastThrowerId = null;
            }

            for (let id in players) {
                let p = players[id];
                if (p.isSpectator) continue;
                
                // 動いているボールがプレイヤーの当たり判定内に入ったかチェック
                if (ball.x > p.x - ball.radius && ball.x < p.x + 30 + ball.radius &&
                    ball.y > p.y - ball.radius && ball.y < p.y + 30 + ball.radius) {
                    
                    // 1. 【新機能】同じチームのプレイヤーに当たった場合は「パス」としてキャッチさせる
                    if (ball.lastOwnerTeam === p.team) {
                        // ただし、自分が投げたボールを自分で即座にキャッチするのを防ぐ（投げてすぐ跳ね返った場合を除く）
                        if (ball.lastThrowerId === id) continue;

                        // すでに別のボールを持っていない場合のみパスを受け取れる
                        const alreadyHolding = balls.some(b => b.owner === id);
                        if (!alreadyHolding) {
                            ball.owner = id;
                            ball.dx = 0;
                            ball.dy = 0;
                            ball.lastOwnerTeam = null;
                            ball.lastThrowerId = null;
                            ball.holdStartTime = now;
                            console.log(`[パス成功] ${p.name} が味方からのパスをキャッチしました。`);
                            break;
                        }
                    } 
                    // 2. 敵チームのプレイヤーに当たった場合は「ヒット（アウト）」判定
                    else if (ball.lastOwnerTeam !== null && ball.lastOwnerTeam !== p.team) {
                        if (p.isOutfield) continue; // すでに外野の人はセーフ

                        p.isOutfield = true;
                        p.x = p.team === 'blue' ? Math.random() * 150 + 1200 : Math.random() * 150 + 20;
                        p.y = Math.random() * 450 + 50;
                        io.to(id).emit('youAreOut');

                        if (ball.lastThrowerId) {
                            const thrower = players[ball.lastThrowerId];
                            if (thrower && thrower.isOutfield) {
                                thrower.isOutfield = false;
                                thrower.x = thrower.team === 'blue' ? Math.random() * 350 + 300 : Math.random() * 350 + 750;
                                thrower.y = Math.random() * 450 + 50;
                            }
                        }

                        ball.lastOwnerTeam = null;
                        ball.lastThrowerId = null;
                        
                        io.emit('playerUpdate', players);
                        break;
                    }
                }
            }
        } else {
            const ownerPlayer = players[ball.owner];
            if (ownerPlayer) {
                if (ball.holdStartTime && (now - ball.holdStartTime > 5000)) {
                    ball.owner = "free";
                    ball.lastOwnerTeam = null;
                    ball.lastThrowerId = null;
                    ball.holdStartTime = null;
                    ball.dx = (Math.random() - 0.5) * 2;
                    ball.dy = 2; 
                } else {
                    ball.x = ownerPlayer.x + 15;
                    ball.y = ownerPlayer.y - ball.radius + 5;
                }
            } else {
                ball.owner = "free";
                ball.lastOwnerTeam = null;
                ball.lastThrowerId = null;
                ball.holdStartTime = null;
            }
        }
    });

    const activePlayers = Object.values(players).filter(p => !p.isSpectator);
    const blueInside = activePlayers.filter(p => p.team === 'blue' && !p.isOutfield).length;
    const redInside = activePlayers.filter(p => p.team === 'red' && !p.isOutfield).length;
    
    const blueTotal = activePlayers.filter(p => p.team === 'blue').length;
    const redTotal = activePlayers.filter(p => p.team === 'red').length;

    if (blueTotal > 0 && redTotal > 0) {
        let roundOver = false;
        let winnerTeam = "";

        if (blueInside === 0) {
            scores.red++;
            winnerTeam = '紅（RED）';
            roundOver = true;
        } else if (redInside === 0) {
            scores.blue++;
            winnerTeam = '蒼（BLUE）';
            roundOver = true;
        }

        if (roundOver) {
            if (scores.blue >= 8) {
                finalWinner = "青チーム (BLUE TEAM)";
                gameState = 'waiting';
                io.emit('finalMatchOver', { finalWinner, scores });
            } else if (scores.red >= 8) {
                finalWinner = "赤チーム (RED TEAM)";
                gameState = 'waiting';
                io.emit('finalMatchOver', { finalWinner, scores });
            } else {
                io.emit('matchOver', { winnerTeam, scores });
                resetRound();
            }
        }
    }

    io.emit('gameUpdate', { balls, players, scores, finalWinner, gameState });
}, 1000 / 60);

function resetRound() {
    for (let id in players) {
        if (players[id].isSpectator) continue;
        players[id].isOutfield = false;
        if (players[id].team === 'blue') {
            players[id].x = Math.random() * 350 + 300;
        } else {
            players[id].x = Math.random() * 350 + 750;
        }
        players[id].y = Math.random() * 450 + 50;
    }
    balls = [];
    adjustBallCount();
}

function fullResetGame() {
    scores = { blue: 0, red: 0 };
    finalWinner = null;
    gameState = 'waiting';
    for (let id in players) {
        players[id].isSpectator = false;
        players[id].isOutfield = false;
    }
    resetRound();
    io.emit('adminResetNotify');
}

io.on('connection', (socket) => {
    socket.on('join', (data) => {
        const shouldSpectate = (gameState === 'playing' || gameState === 'paused');
        const team = assignTeam();
        
        let customName = data.name ? data.name.trim() : "";
        if (!customName) {
            customName = (team === 'blue' ? "青_" : "赤_") + Math.floor(Math.random() * 90 + 10);
        }
        if (shouldSpectate) {
            customName = "[観戦]" + customName;
        }

        const spawnX = shouldSpectate ? -999 : (team === 'blue' ? Math.random() * 350 + 300 : Math.random() * 350 + 750);

        players[socket.id] = {
            id: socket.id,
            name: customName,
            team: team,
            x: spawnX,
            y: shouldSpectate ? -999 : Math.random() * 450 + 50,
            isOutfield: false,
            isSpectator: shouldSpectate
        };

        if (!shouldSpectate) {
            adjustBallCount();
        }
        
        socket.emit('init', { myId: socket.id, players, balls, scores, finalWinner, gameState });
    });

    socket.on('move', (data) => {
        const p = players[socket.id];
        if (p && gameState === 'playing' && !p.isSpectator && !finalWinner) {
            let targetX = data.x;
            let targetY = data.y;

            if (!p.isOutfield) {
                if (p.team === 'blue') {
                    if (targetX < 200) targetX = 200;
                    if (targetX > 700 - 30) targetX = 700 - 30;
                } else {
                    if (targetX < 700) targetX = 700;
                    if (targetX > 1200 - 30) targetX = 1200 - 30;
                }
            } else {
                if (p.team === 'blue') {
                    if (targetX < 1200) targetX = 1200;
                    if (targetX > 1400 - 30) targetX = 1400 - 30;
                } else {
                    if (targetX < 0) targetX = 0;
                    if (targetX > 200 - 30) targetX = 200 - 30;
                }
            }
            p.x = targetX;
            p.y = targetY;
        }
    });

    socket.on('ballAction', (data) => {
        if (gameState !== 'playing' || finalWinner) return;
        const p = players[socket.id];
        if (!p || p.isSpectator) return;

        const targetBall = balls.find(b => b.id === data.ballId);
        if (!targetBall) return;

        if (data.action === "catch" && targetBall.owner === "free") {
            const alreadyHolding = balls.some(b => b.owner === socket.id);
            if (!alreadyHolding) {
                targetBall.owner = socket.id;
                targetBall.dx = 0;
                targetBall.dy = 0;
                targetBall.lastOwnerTeam = null;
                targetBall.lastThrowerId = null;
                targetBall.holdStartTime = Date.now();
            }
        } else if (data.action === "throw" && targetBall.owner === socket.id) {
            targetBall.owner = "free";
            targetBall.lastOwnerTeam = p.team;
            targetBall.lastThrowerId = socket.id;
            targetBall.dx = data.dx;
            targetBall.dy = data.dy;
            targetBall.holdStartTime = null;
        }
    });

    socket.on('adminControl', (data) => {
        const correctPassword = "Otosupo2013";
        if (!data || data.password !== correctPassword) {
            socket.emit('adminAuthFailed');
            return;
        }

        if (data.command === 'start') {
            gameState = 'playing';
        } else if (data.command === 'pause') {
            gameState = 'paused';
        } else if (data.command === 'reset') {
            fullResetGame();
        }
    });

    socket.on('adminChangeTeam', (data) => {
        const correctPassword = "Sasd1213";
        if (!data || data.password !== correctPassword) {
            socket.emit('adminAuthFailed');
            return;
        }

        const targetPlayer = players[data.targetId];
        if (!targetPlayer) return;

        if (data.newTeam === 'spectator') {
            targetPlayer.isSpectator = true;
            targetPlayer.x = -999;
            targetPlayer.y = -999;
            balls.forEach(b => {
                if (b.owner === targetPlayer.id) {
                    b.owner = "free";
                    b.holdStartTime = null;
                }
            });
        } else {
            targetPlayer.isSpectator = false;
            targetPlayer.team = data.newTeam;
            targetPlayer.isOutfield = false;
            targetPlayer.x = data.newTeam === 'blue' ? Math.random() * 350 + 300 : Math.random() * 350 + 750;
            targetPlayer.y = Math.random() * 450 + 50;
        }
        
        adjustBallCount();
        io.emit('gameUpdate', { balls, players, scores, finalWinner, gameState });
    });

    socket.on('disconnect', () => {
        delete players[socket.id];
        balls = balls.filter(b => b.owner !== socket.id);
        adjustBallCount();
        io.emit('gameUpdate', { balls, players, scores, finalWinner, gameState });
    });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
});