const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

const ADMIN_PASSWORD = 'Otosupo2013';

// --- ゲーム状態管理 ---
let gameState = {
    status: 'lobby', 
    players: {},     
    scores: { red: 0, blue: 0 },
    votes: { red: 'STAY', blue: 'STAY' }, // 最終的な多数決の結果
    timer: 20,                            // 20秒考える時間に変更
    round: 0
};

// 各プレイヤーの個別投票を保存するオブジェクト { socketId: 'PUSH' | 'STAY' }
let playerVotes = {};
let gameInterval = null;

function resetGame() {
    gameState.status = 'lobby';
    gameState.scores = { red: 0, blue: 0 };
    gameState.votes = { red: 'STAY', blue: 'STAY' };
    gameState.timer = 20;
    gameState.round = 0;
    playerVotes = {};
    
    Object.keys(gameState.players).forEach(id => {
        gameState.players[id].isSpectator = false;
        if (gameState.players[id].team === 'spectator') {
            gameState.players[id].team = null;
        }
    });

    if (gameInterval) clearInterval(gameInterval);
}

function broadcastState() {
    io.emit('stateUpdate', gameState);
}

function startRound() {
    gameState.status = 'playing';
    gameState.timer = 20; // 20秒
    gameState.votes = { red: 'STAY', blue: 'STAY' };
    playerVotes = {}; // 投票リセット
    broadcastState();

    gameInterval = setInterval(() => {
        gameState.timer--;
        if (gameState.timer <= 0) {
            clearInterval(gameInterval);
            aggregateVotes(); // 20秒終了時に多数決を集計
        } else {
            broadcastState();
        }
    }, 1000);
}

// 多数決の集計処理
function aggregateVotes() {
    gameState.status = 'interval';

    // チームごとのPUSH票をカウント
    let redPushCount = 0;
    let redTotal = 0;
    let bluePushCount = 0;
    let blueTotal = 0;

    Object.values(gameState.players).forEach(p => {
        if (!p.name || p.isSpectator) return;
        const vote = playerVotes[p.id] || 'STAY'; // 押してない人は自動的にSTAY
        
        if (p.team === 'red') {
            redTotal++;
            if (vote === 'PUSH') redPushCount++;
        }
        if (p.team === 'blue') {
            blueTotal++;
            if (vote === 'PUSH') bluePushCount++;
        }
    });

    // 赤チームの判定 (過半数を超えていればPUSH、引き分け・以下ならSTAY)
    // 例: 4人中2人PUSHなら引き分けでSTAY。3人PUSHなら過半数でPUSH。
    const redStayCount = redTotal - redPushCount;
    if (redPushCount > redStayCount) {
        gameState.votes.red = 'PUSH';
    } else {
        gameState.votes.red = 'STAY';
    }

    // 青チームの判定
    const blueStayCount = blueTotal - bluePushCount;
    if (bluePushCount > blueStayCount) {
        gameState.votes.blue = 'PUSH';
    } else {
        gameState.votes.blue = 'STAY';
    }

    // 民主主義の決議文テキストを作成
    const redResultText = gameState.votes.red === 'PUSH' ? '『追加（PUSH）』と可決しました' : '『ステイ（STAY）』と可決しました';
    const blueResultText = gameState.votes.blue === 'PUSH' ? '『追加（PUSH）』と可決しました' : '『ステイ（STAY）』と可決しました';

    const democracyMessage = `
        【赤チーム（Red）】<br>
        健全なる民主主義の結果、${redResultText}。<br>
        (PUSH: ${redPushCount}票 / STAY: ${redStayCount}票)<br><br>
        【青チーム（Blue）】<br>
        健全なる民主主義の結果、${blueResultText}。<br>
        (PUSH: ${bluePushCount}票 / STAY: ${blueStayCount}票)
    `;

    // まず多数決の可決メッセージを全員に表示 (6秒間)
    io.emit('democracyResult', democracyMessage);

    // 6秒後に、本来のラウンド結末とスコアを判定して表示
    setTimeout(() => {
        evaluateRound();
    }, 6000);
}

function evaluateRound() {
    const redAction = gameState.votes.red;
    const blueAction = gameState.votes.blue;
    let resultMessage = '';

    if (redAction === 'PUSH' && blueAction === 'STAY') {
        gameState.scores.red += 1;
        resultMessage = '🔴 赤チームが攻めた！赤チームに1ポイント！';
    } else if (redAction === 'STAY' && blueAction === 'PUSH') {
        gameState.scores.blue += 1;
        resultMessage = '🔵 青チームが攻めた！青チームに1ポイント！';
    } else if (redAction === 'PUSH' && blueAction === 'PUSH') {
        gameState.scores.red = 0;
        gameState.scores.blue = 0;
        resultMessage = '💥 大爆発（BOMB）！両チームとも 0点 にリセット！';
    } else {
        resultMessage = '🐔 双方チキン（STAY）！何も起きなかった...';
    }

    io.emit('roundResult', {
        votes: gameState.votes,
        scores: { ...gameState.scores },
        message: resultMessage
    });

    if (gameState.scores.red >= 3) {
        setTimeout(() => {
            io.emit('gameOver', { winner: '赤チーム (Red)' });
            resetGame();
            broadcastState();
        }, 4000);
    } else if (gameState.scores.blue >= 3) {
        setTimeout(() => {
            io.emit('gameOver', { winner: '青チーム (Blue)' });
            resetGame();
            broadcastState();
        }, 4000);
    } else {
        setTimeout(() => {
            gameState.round++;
            startRound();
        }, 4000);
    }
}

// --- Socket.io 通信 ---
io.on('connection', (socket) => {
    gameState.players[socket.id] = { id: socket.id, name: '', team: null, isSpectator: false };
    
    socket.on('login', (name) => {
        const player = gameState.players[socket.id];
        if (player) {
            player.name = name;
            if (gameState.status === 'playing' || gameState.status === 'interval') {
                player.isSpectator = true;
                player.team = 'spectator';
            }
            broadcastState();
        }
    });

    socket.on('joinTeam', (team) => {
        const player = gameState.players[socket.id];
        if (player && player.name && !player.isSpectator) {
            player.team = team;
            broadcastState();
        }
    });

    socket.on('sendChat', (message) => {
        const player = gameState.players[socket.id];
        if (player && player.team && player.name) {
            Object.keys(gameState.players).forEach((id) => {
                if (gameState.players[id].team === player.team) {
                    io.to(id).emit('receiveChat', {
                        sender: player.name,
                        message: message
                    });
                }
            });
        }
    });

    // アクションボタンが押された時 (多数決用の個別投票として記録)
    socket.on('pushAction', () => {
        const player = gameState.players[socket.id];
        if (player && player.team && gameState.status === 'playing' && !player.isSpectator) {
            // トグル制（一度押してもう一度押すとSTAYに戻る）ではなく、
            // 「PUSH（押す）」に1票を投じた状態にする（1回押せば確定）
            playerVotes[socket.id] = 'PUSH';
            socket.emit('myVoteUpdated', 'PUSH');
        }
    });

    socket.on('startGame', (password) => {
        if (password === ADMIN_PASSWORD) {
            resetGame();
            gameState.round = 1;
            startRound();
        } else {
            socket.emit('adminError', 'パスワードが間違っています。');
        }
    });

    socket.on('forceRestart', (password) => {
        if (password === ADMIN_PASSWORD) {
            gameState.scores = { red: 0, blue: 0 };
            gameState.votes = { red: 'STAY', blue: 'STAY' };
            gameState.timer = 20;
            
            Object.keys(gameState.players).forEach(id => {
                gameState.players[id].isSpectator = false;
                if (gameState.players[id].team === 'spectator') {
                    gameState.players[id].team = null;
                }
            });

            if (gameInterval) clearInterval(gameInterval);
            gameState.round = 1;
            startRound();
            io.emit('gameRestarts');
        } else {
            socket.emit('adminError', 'パスワードが間違っています。');
        }
    });

    socket.on('abortGame', (password) => {
        if (password === ADMIN_PASSWORD) {
            resetGame();
            io.emit('gameAborted');
            broadcastState();
        } else {
            socket.emit('adminError', 'パスワードが間違っています。');
        }
    });

    socket.on('disconnect', () => {
        delete gameState.players[socket.id];
        delete playerVotes[socket.id];
        broadcastState();
    });
});

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on port ${PORT}`);
});