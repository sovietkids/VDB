const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

const WIDTH = 1200; 
const HEIGHT = 600;
const FPS = 60;

const ADMIN_PASSWORD = "Otosupo2013";

let seesaws = {
    red: { cx: 250, cy: HEIGHT - 150, length: 360, thickness: 20, angle: 0, angularVelocity: 0, maxAngle: Math.PI / 6, restoringForce: 0.002, friction: 0.92, color: '#ff3b30' },
    blue: { cx: 950, cy: HEIGHT - 150, length: 360, thickness: 20, angle: 0, angularVelocity: 0, maxAngle: Math.PI / 6, restoringForce: 0.002, friction: 0.92, color: '#007aff' }
};

const PLAYER_WEIGHT = 0.00003; 
const ITEM_WEIGHT = 0.00001;   
const SLIDE_GRAVITY = 0.3;     
const MOVE_SPEED = 4;
const GRAVITY_Y = 0.15; 

let players = {};
let items = [];
let itemIds = 0;
let teamToggle = true; 
let winnerTeam = null; 
let scores = { red: 0, blue: 0 };
let gameStatus = 'lobby'; 
let roundTimerId = null; // 次のラウンドへのタイマー管理用

function checkGameSet() {
    if (gameStatus !== 'playing' || winnerTeam) return; 

    let redAlive = 0; let blueAlive = 0;
    let redTotal = 0; let blueTotal = 0;

    Object.values(players).forEach(p => {
        if (!p.isSpectator) { // 観戦者は計算に入れない
            if (p.team === 'red') { redTotal++; if (p.isAlive) redAlive++; }
            else if (p.team === 'blue') { blueTotal++; if (p.isAlive) blueAlive++; }
        }
    });

    if (redTotal > 0 && blueTotal > 0) {
        if (redAlive === 0) {
            winnerTeam = 'blue'; scores.blue++;
            roundTimerId = setTimeout(readyForNextRound, 5000); 
        } else if (blueAlive === 0) {
            winnerTeam = 'red'; scores.red++;
            roundTimerId = setTimeout(readyForNextRound, 5000); 
        }
    }
}

function readyForNextRound() {
    winnerTeam = null;
    items = [];
    seesaws.red.angle = 0; seesaws.red.angularVelocity = 0;
    seesaws.blue.angle = 0; seesaws.blue.angularVelocity = 0;
    
    Object.values(players).forEach(player => {
        // 途中参加した観戦者も、次のラウンドからは正式にプレイヤーとして復活させる
        if (player.isSpectator) {
            player.isSpectator = false;
        }
        const seesaw = seesaws[player.team];
        player.x = seesaw.cx + (Math.random() * 60 - 30);
        player.y = seesaw.cy - 50;
        player.isAlive = true;
        player.lastShot = 0;
        player.inputs = { left: false, right: false };
    });
}

function startGame() {
    gameStatus = 'playing';
    winnerTeam = null;
    items = [];
    // 開始時にいるメンバー全員の準備状態・観戦状態を初期化
    Object.values(players).forEach(p => {
        p.isSpectator = false;
    });
    readyForNextRound();
    io.emit('gameStarted', { gameStatus: 'playing' });
    console.log("GAME OFFICIALLY STARTED");
}

// ★ 管理者用：強制終了してロビーに戻る関数
function abortToLobby() {
    if (roundTimerId) clearTimeout(roundTimerId);
    gameStatus = 'lobby';
    winnerTeam = null;
    items = [];
    seesaws.red.angle = 0; seesaws.red.angularVelocity = 0;
    seesaws.blue.angle = 0; seesaws.blue.angularVelocity = 0;

    Object.values(players).forEach(p => {
        p.isReady = false;
        p.isAlive = true;
        p.isSpectator = false;
        p.lastShot = 0;
        p.inputs = { left: false, right: false };
    });
    io.emit('gameAborted');
    console.log("GAME FORCIBLY ABORTED TO LOBBY");
}

io.on('connection', (socket) => {
    console.log(`ユーザー接続: ${socket.id}`);

    const team = teamToggle ? 'red' : 'blue';
    teamToggle = !teamToggle;
    const seesaw = seesaws[team];

    // ★ 途中参加制限のロジック
    // 既に試合中の場合は「isSpectator: true, isAlive: false」として参加させ、特権を縛る
    const isMidJoin = (gameStatus === 'playing');

    players[socket.id] = {
        id: socket.id,
        name: `プレイヤー_${socket.id.substring(0, 4)}`,
        team: team,
        isReady: false,
        isAdmin: false, 
        x: seesaw.cx,
        y: seesaw.cy - 50,
        radius: 15,
        color: team === 'red' ? '#ff6b6b' : '#4dabf7',
        inputs: { left: false, right: false },
        isAlive: !isMidJoin,       // 途中参加なら死亡状態スタート
        isSpectator: isMidJoin,   // 途中参加なら観戦者フラグオン
        lastShot: 0 
    };

    // 途中参加者には現在のステータスを即座に通知
    if (isMidJoin) {
        socket.emit('midJoinAlert');
    }

    socket.on('changeName', (newName) => {
        if (!newName || typeof newName !== 'string') return;
        const sanitizedName = newName.trim().substring(0, 12);
        if (sanitizedName && players[socket.id]) {
            players[socket.id].name = sanitizedName;
        }
    });

    socket.on('authAdmin', (password) => {
        if (password === ADMIN_PASSWORD) {
            if (players[socket.id]) {
                players[socket.id].isAdmin = true;
                socket.emit('adminAuthResult', { success: true });
            }
        } else {
            socket.emit('adminAuthResult', { success: false });
        }
    });

    socket.on('changeTeam', (newTeam) => {
        if (gameStatus !== 'lobby') return;
        if (players[socket.id] && (newTeam === 'red' || newTeam === 'blue')) {
            players[socket.id].team = newTeam;
            players[socket.id].color = newTeam === 'red' ? '#ff6b6b' : '#4dabf7';
        }
    });

    socket.on('toggleReady', () => {
        if (gameStatus !== 'lobby') return;
        if (players[socket.id]) {
            players[socket.id].isReady = !players[socket.id].isReady;
        }
    });

    socket.on('adminStartGame', () => {
        if (!players[socket.id] || !players[socket.id].isAdmin || gameStatus !== 'lobby') return;
        startGame();
    });

    // ★ 強制終了イベントのキャッチ
    socket.on('adminAbortGame', () => {
        if (!players[socket.id] || !players[socket.id].isAdmin || gameStatus !== 'playing') return;
        abortToLobby();
    });

    socket.on('adminResetScores', () => {
        if (!players[socket.id] || !players[socket.id].isAdmin) return;
        scores = { red: 0, blue: 0 };
    });

    socket.on('input', (inputs) => {
        if (gameStatus === 'playing' && players[socket.id] && !winnerTeam && !players[socket.id].isSpectator) {
            players[socket.id].inputs = inputs;
        }
    });

    socket.on('throwBlock', (mouseData) => {
        if (gameStatus !== 'playing' || winnerTeam) return; 
        const player = players[socket.id];
        if (!player || !player.isAlive || player.isSpectator) return; // 観戦者は投げられない
        if (!mouseData || typeof mouseData.x !== 'number' || typeof mouseData.y !== 'number') return;

        const now = Date.now();
        if (now - player.lastShot < 10000) return; 
        player.lastShot = now;

        const enemyTeam = player.team === 'red' ? 'blue' : 'red';
        const dx = mouseData.x - player.x;
        const dy = mouseData.y - player.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance === 0) return;

        const speed = Math.min(distance * 0.04, 15); 
        const vx = (dx / distance) * speed;
        const vy = (dy / distance) * speed;

        items.push({
            id: itemIds++, x: player.x, y: player.y - 20, vx: vx, vy: vy, size: 22,
            color: player.team === 'red' ? '#ff3b30' : '#007aff', onSeesaw: false, targetTeam: enemyTeam, relativeX: 0
        });
    });

    socket.on('disconnect', () => {
        delete players[socket.id];
        checkGameSet();
    });
});

setInterval(() => {
    if (gameStatus === 'playing') {
        let torques = { red: 0, blue: 0 };

        Object.values(players).forEach(player => {
            if (!player.isAlive || player.isSpectator) return;
            const seesaw = seesaws[player.team];
            const relativeX = player.x - seesaw.cx;
            const seesawY = seesaw.cy + relativeX * Math.sin(seesaw.angle);

            if (player.inputs.left) player.x -= MOVE_SPEED;
            if (player.inputs.right) player.x += MOVE_SPEED;

            player.x += Math.sin(seesaw.angle) * SLIDE_GRAVITY * 10;
            player.y = seesawY - player.radius;

            if (Math.abs(relativeX) > seesaw.length / 2 || player.y > HEIGHT) {
                player.isAlive = false;
                checkGameSet(); 
            } else {
                torques[player.team] += relativeX * PLAYER_WEIGHT;
            }
        });

        items.forEach((item, index) => {
            const seesaw = seesaws[item.targetTeam]; 
            if (!item.onSeesaw) {
                item.x += item.vx; item.y += item.vy; item.vy += GRAVITY_Y;
                const dx = item.x - seesaw.cx; const dy = item.y - seesaw.cy;
                const cos = Math.cos(-seesaw.angle); const sin = Math.sin(-seesaw.angle);
                const localX = dx * cos - dy * sin; const localY = dx * sin + dy * cos;

                if (Math.abs(localX) <= seesaw.length / 2 && localY >= -item.size && localY <= seesaw.thickness && item.vy > 0) {
                    item.onSeesaw = true; item.relativeX = localX; item.vx = 0; item.vy = 0;
                }
                if (item.y > HEIGHT || item.x < 0 || item.x > WIDTH) items.splice(index, 1);
            } else {
                item.relativeX += Math.sin(seesaw.angle) * SLIDE_GRAVITY * 10;
                item.x = seesaw.cx + item.relativeX * Math.cos(seesaw.angle);
                item.y = seesaw.cy + item.relativeX * Math.sin(seesaw.angle) - item.size;
                if (Math.abs(item.relativeX) > seesaw.length / 2 || item.y > HEIGHT) {
                    items.splice(index, 1); return;
                }
                torques[item.targetTeam] += item.relativeX * ITEM_WEIGHT;
            }
        });

        ['red', 'blue'].forEach(team => {
            const seesaw = seesaws[team]; seesaw.angularVelocity += torques[team];
            if (seesaw.angle > 0) seesaw.angularVelocity -= seesaw.restoringForce;
            if (seesaw.angle < 0) seesaw.angularVelocity += seesaw.restoringForce;
            seesaw.angularVelocity *= seesaw.friction; seesaw.angle += seesaw.angularVelocity;
            if (seesaw.angle > seesaw.maxAngle) { seesaw.angle = seesaw.maxAngle; seesaw.angularVelocity = 0; }
            if (seesaw.angle < -seesaw.maxAngle) { seesaw.angle = -seesaw.maxAngle; seesaw.angularVelocity = 0; }
        });
    }

    io.emit('gameState', { seesaws, players, items, winnerTeam, scores, gameStatus });
}, 1000 / FPS);

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => console.log(`Server running on http://YOUR_LOCAL_IP:${PORT}`));