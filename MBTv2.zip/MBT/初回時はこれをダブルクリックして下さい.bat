@echo off
npm install