@echo off
rem 文字化け対策（UTF-8に変更）
chcp 65001 > nul

echo ===================================================
echo  サーバーを起動しています...
echo ===================================================

set LOCAL_IP=localhost

rem IPv4アドレスを自動取得して変数に格納 (スペースの配置を修正)
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /R /C:"IPv4 アドレス" /C:"IPv4 Address"') do (
    set LOCAL_IP=%%a
)

rem 空白を削除
set LOCAL_IP=%LOCAL_IP: =%

echo.
echo ---------------------------------------------------
echo  ブラウザで以下のURLにアクセスしてください：
echo  http://%LOCAL_IP%:3000
echo ---------------------------------------------------
echo.

rem Node.js サーバーの起動
node server.js

pause