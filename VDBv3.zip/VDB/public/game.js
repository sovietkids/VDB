const userName = prompt("ゲームで使用する名前を入力してください（空欄ならランダム）：");
const socket = io();

socket.emit('join', { name: userName });

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const statusElement = document.getElementById("status");
const resetBtn = document.getElementById("reset-btn");

const adminContainer = resetBtn.parentElement;
const startBtn = document.createElement("button");
startBtn.textContent = "▶ 試合スタート";
startBtn.style.marginRight = "10px";
const pauseBtn = document.createElement("button");
pauseBtn.textContent = "⏸ 中断 (ポーズ)";
pauseBtn.style.marginRight = "10px";

const manageBtn = document.createElement("button");
manageBtn.textContent = "👥 メンバー管理";
manageBtn.style.marginRight = "10px";
manageBtn.style.backgroundColor = "#4caf50";
manageBtn.style.color = "white";

adminContainer.insertBefore(startBtn, resetBtn);
adminContainer.insertBefore(pauseBtn, resetBtn);
adminContainer.insertBefore(manageBtn, resetBtn);

let myId = null;
let players = {};
let balls = [];
let scores = { blue: 0, red: 0 }; 
let finalWinner = null;            
let winMessage = ""; 
let gameState = 'waiting'; 

startBtn.addEventListener("click", () => {
    const pass = prompt("管理者パスワードを入力してください：");
    if (pass === null) return;
    socket.emit('adminControl', { command: 'start', password: pass });
});

pauseBtn.addEventListener("click", () => {
    const pass = prompt("管理者パスワードを入力してください：");
    if (pass === null) return;
    socket.emit('adminControl', { command: 'pause', password: pass });
});

resetBtn.addEventListener("click", () => {
    const pass = prompt("管理者パスワードを入力してください：");
    if (pass === null) return;
    socket.emit('adminControl', { command: 'reset', password: pass });
});

manageBtn.addEventListener("click", () => {
    const pass = prompt("管理者パスワードを入力してください：");
    if (pass === null) return;

    let playerListStr = "変更したいプレイヤーの番号を入力してください：\n";
    const pArray = Object.values(players);
    
    pArray.forEach((p, idx) => {
        let teamStr = p.isSpectator ? "観戦" : (p.team === 'blue' ? "青" : "赤");
        playerListStr += `${idx}: ${p.name} (現在: ${teamStr})\n`;
    });

    const targetIdxStr = prompt(playerListStr);
    if (targetIdxStr === null || targetIdxStr === "") return;
    const targetIdx = parseInt(targetIdxStr);

    if (isNaN(targetIdx) || targetIdx < 0 || targetIdx >= pArray.length) {
        alert("無効な番号です。");
        return;
    }

    const selectedPlayer = pArray[targetIdx];
    const newTeamSelect = prompt(`「${selectedPlayer.name}」の移動先を数字で選んでください：\n1: 青チームへ移動\n2: 赤チームへ移動\n3: 観戦モードへ移動`);
    
    let newTeam = "";
    if (newTeamSelect === "1") newTeam = "blue";
    else if (newTeamSelect === "2") newTeam = "red";
    else if (newTeamSelect === "3") newTeam = "spectator";
    else {
        alert("キャンセルされました。");
        return;
    }

    socket.emit('adminChangeTeam', {
        password: pass,
        targetId: selectedPlayer.id,
        newTeam: newTeam
    });
});

const playerSpeed = 4;
const keys = {};

window.addEventListener("keydown", (e) => { keys[e.code] = true; });
window.addEventListener("keyup", (e) => { keys[e.code] = false; });

// スペースキーでの敵玉キャッチ
window.addEventListener("keydown", (e) => {
    if (gameState !== 'playing' || winMessage || finalWinner) return;
    if (e.code === "Space") {
        const me = players[myId];
        if (!me || me.isSpectator) return;

        let closestBall = null;
        let minDist = 74; 

        balls.forEach(b => {
            // 敵が投げたボール（かつ、まだ誰も持ってない）をキャッチ対象にする
            if (b.owner === "free" && b.lastOwnerTeam !== null && b.lastOwnerTeam !== me.team) {
                let dist = Math.hypot(b.x - (me.x + 15), b.y - (me.y + 15));
                if (dist < minDist) {
                    minDist = dist;
                    closestBall = b;
                }
            }
            // まだ誰も投げてない初期ボールもキャッチ可能
            else if (b.owner === "free" && b.lastOwnerTeam === null) {
                let dist = Math.hypot(b.x - (me.x + 15), b.y - (me.y + 15));
                if (dist < minDist) {
                    minDist = dist;
                    closestBall = b;
                }
            }
        });

        if (closestBall) {
            socket.emit('ballAction', { action: "catch", ballId: closestBall.id });
        }
    }
});

canvas.addEventListener("mousedown", (e) => {
    if (gameState !== 'playing' || winMessage || finalWinner) return;

    const myBall = balls.find(b => b.owner === myId);
    if (!myBall) return;

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const me = players[myId];
    if (!me || me.isSpectator) return;

    const playerCenterX = me.x + 15;
    const playerCenterY = me.y + 15;

    const diffX = mouseX - playerCenterX;
    const diffY = mouseY - playerCenterY;
    const distance = Math.hypot(diffX, diffY);

    if (distance === 0) return;

    const throwSpeed = 7;
    let dx = (diffX / distance) * throwSpeed;
    let dy = (diffY / distance) * throwSpeed;

    socket.emit('ballAction', {
        action: "throw",
        ballId: myBall.id,
        dx: dx,
        dy: dy
    });
});

socket.on('init', (data) => {
    myId = data.myId;
    players = data.players;
    balls = data.balls;
    scores = data.scores;
    finalWinner = data.finalWinner;
    gameState = data.gameState;
    updateStatus();
});

socket.on('gameUpdate', (data) => {
    players = data.players;
    balls = data.balls;
    scores = data.scores;
    finalWinner = data.finalWinner;
    gameState = data.gameState;
    updateStatus();
});

socket.on('playerUpdate', (serverPlayers) => {
    players = serverPlayers;
    updateStatus();
});

socket.on('youAreOut', () => {
    updateStatus();
});

socket.on('matchOver', (data) => {
    scores = data.scores;
    winMessage = `ラウンド終了！ 勝者: ${data.winnerTeam}`;
    setTimeout(() => {
        winMessage = "";
        updateStatus();
    }, 3000);
});

socket.on('finalMatchOver', (data) => {
    scores = data.scores;
    finalWinner = data.finalWinner;
});

socket.on('adminResetNotify', () => {
    winMessage = "管理者によってゲームが初期化されました！";
    finalWinner = null;
    setTimeout(() => {
        winMessage = "";
        updateStatus();
    }, 2000);
});

socket.on('adminAuthFailed', () => {
    alert("❌ パスワードが違います。認証に失敗しました。");
});

function updateStatus() {
    const me = players[myId];
    if (me) {
        if (me.isSpectator) {
            statusElement.textContent = `あなた: ${me.name} (観戦モード中 👁)`;
            statusElement.style.color = "#ffa502";
        } else {
            const roleStr = me.isOutfield ? "外野" : "内野";
            statusElement.textContent = `あなた: ${me.name} (${me.team === 'blue' ? '青チーム' : '赤チーム'}・${roleStr})`;
            statusElement.style.color = "";
        }
    }
}

function update() {
    if (gameState !== 'playing' || winMessage || finalWinner) return; 

    const me = players[myId];
    if (me && !me.isSpectator) {
        let moved = false;
        let tx = me.x;
        let ty = me.y;

        if (keys["ArrowLeft"] || keys["KeyA"]) { tx -= playerSpeed; moved = true; }
        if (keys["ArrowRight"] || keys["KeyD"]) { tx += playerSpeed; moved = true; }
        if (keys["ArrowUp"] || keys["KeyW"]) { ty -= playerSpeed; moved = true; }
        if (keys["ArrowDown"] || keys["KeyS"]) { ty += playerSpeed; moved = true; }

        if (!me.isOutfield) {
            if (me.team === 'blue') {
                if (tx < 200) tx = 200;
                if (tx > 700 - 30) tx = 700 - 30;
            } else {
                if (tx < 700) tx = 700;
                if (tx > 1200 - 30) tx = 1200 - 30;
            }
        } else {
            if (me.team === 'blue') {
                if (tx < 1200) tx = 1200;
                if (tx > 1400 - 30) tx = 1400 - 30;
            } else {
                if (tx < 0) tx = 0;
                if (tx > 200 - 30) tx = 200 - 30;
            }
        }

        if (ty < 0) ty = 0;
        if (ty > canvas.height - 30) ty = canvas.height - 30;

        if (moved) {
            socket.emit('move', { x: tx, y: ty });
        }
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "rgba(255, 50, 50, 0.15)"; ctx.fillRect(0, 0, 200, canvas.height);
    ctx.fillStyle = "rgba(0, 150, 255, 0.05)"; ctx.fillRect(200, 0, 500, canvas.height);
    ctx.fillStyle = "rgba(255, 50, 50, 0.05)"; ctx.fillRect(700, 0, 500, canvas.height);
    ctx.fillStyle = "rgba(0, 150, 255, 0.15)"; ctx.fillRect(1200, 0, 200, canvas.height);

    ctx.strokeStyle = "rgba(255, 255, 255, 0.3)"; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(200, 0); ctx.lineTo(200, canvas.height); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(1200, 0); ctx.lineTo(1200, canvas.height); ctx.stroke();
    ctx.strokeStyle = "rgba(255, 255, 255, 0.6)"; ctx.lineWidth = 6;
    ctx.beginPath(); ctx.moveTo(700, 0); ctx.lineTo(700, canvas.height); ctx.stroke();

    ctx.fillStyle = "rgba(255,255,255,0.8)";
    ctx.font = "bold 36px Arial";
    ctx.textAlign = "center";
    ctx.fillText(`${scores.blue}  -  ${scores.red}`, canvas.width / 2, 45);

    for (let id in players) {
        let p = players[id];
        if (p.isSpectator) continue;

        ctx.fillStyle = p.team === 'blue' ? "#1e90ff" : "#ff4757";
        if (p.isOutfield) ctx.globalAlpha = 0.5;
        ctx.fillRect(p.x, p.y, 30, 30);
        ctx.globalAlpha = 1.0;

        ctx.fillStyle = "#fff"; ctx.font = "11px Arial"; ctx.textAlign = "center";
        ctx.fillText(p.name + (p.isOutfield ? "(外)" : ""), p.x + 15, p.y - 6);

        if (id === myId) {
            ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.strokeRect(p.x - 2, p.y - 2, 34, 34);
        }
    }

    balls.forEach(b => {
        if (b.owner === "free") {
            ctx.fillStyle = "#ffa502";
        } else {
            const owner = players[b.owner];
            ctx.fillStyle = owner?.team === 'blue' ? "#1e90ff" : "#ff4757";
        }
        ctx.beginPath(); ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2); ctx.fill();
        
        if (b.owner === "free") {
            ctx.fillStyle = "#fff";
            ctx.beginPath(); ctx.arc(b.x, b.y, b.radius / 2, 0, Math.PI * 2); ctx.fill();
        }
    });

    if (gameState === 'waiting' && !finalWinner && !winMessage) {
        ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#fff"; ctx.font = "bold 26px Arial"; ctx.textAlign = "center";
        ctx.fillText("⏸ 試合開始 待機中...", canvas.width / 2, canvas.height / 2);
        ctx.font = "16px Arial"; ctx.fillStyle = "#ccc";
        ctx.fillText("管理者が「試合スタート」を押すと開始します", canvas.width / 2, canvas.height / 2 + 40);
    }

    if (gameState === 'paused') {
        ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#ffa502"; ctx.font = "bold 32px Arial"; ctx.textAlign = "center";
        ctx.fillText("⏸ 一時中断中 (PAUSED)", canvas.width / 2, canvas.height / 2);
    }

    if (winMessage) {
        ctx.fillStyle = "rgba(0,0,0,0.8)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = winMessage.includes("BLUE") || winMessage.includes("蒼") ? "#1e90ff" : "#ff4757";
        ctx.font = "bold 32px Arial"; ctx.textAlign = "center";
        ctx.fillText(winMessage, canvas.width / 2, canvas.height / 2);
    }

    if (finalWinner) {
        ctx.fillStyle = "rgba(0,0,0,0.95)"; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = finalWinner.includes("BLUE") ? "#1e90ff" : "#ff4757";
        ctx.font = "bold 42px Arial"; ctx.textAlign = "center";
        ctx.fillText("🏆 MATCH OVER 🏆", canvas.width / 2, canvas.height / 2 - 40);
        ctx.fillStyle = "#fff";
        ctx.font = "28px Arial";
        ctx.fillText(`勝者: ${finalWinner}`, canvas.width / 2, canvas.height / 2 + 20);
    }

    const me = players[myId];
    if (me && me.isSpectator) {
        ctx.fillStyle = "rgba(255, 165, 0, 0.8)";
        ctx.font = "bold 16px Arial"; ctx.textAlign = "left";
        ctx.fillText("👁 現在観戦モード中（次のゲームリセットまで参加できません）", 20, canvas.height - 20);
    }
}

function loop() {
    update();
    draw();
    requestAnimationFrame(loop);
}

loop();