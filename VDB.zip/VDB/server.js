const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

let players = {};
let balls = [];
let scores = { blue: 0, red: 0 };
let finalWinner = null; 

// ★ ゲームの状態管理 ('waiting', 'playing', 'paused')
let gameState = 'waiting';

function assignTeam() {
    const counts = { blue: 0, red: 0 };
    Object.values(players).forEach(p => {
        if (p.isSpectator) return; // 観戦者はカウントしない
        if (p.team === 'blue') counts.blue++;
        if (p.team === 'red') counts.red++;
    });
    return counts.blue <= counts.red ? 'blue' : 'red';
}

function adjustBallCount() {
    // 観戦者を除いたプレイヤー数でボール数を決める
    const activePlayerCount = Object.values(players).filter(p => !p.isSpectator).length;
    const targetBallCount = Math.max(1, Math.floor(activePlayerCount / 4));
    
    while (balls.length < targetBallCount) {
        balls.push({
            id: Math.random().toString(36).substr(2, 9),
            x: 500,
            y: 200,
            dx: (Math.random() - 0.5) * 5,
            dy: (Math.random() - 0.5) * 5,
            radius: 24,
            owner: "free",
            lastOwnerTeam: null,
            lastThrowerId: null,
            holdStartTime: null
        });
    }

    while (balls.length > targetBallCount) {
        const freeBallIndex = balls.findIndex(b => b.owner === "free");
        if (freeBallIndex !== -1) {
            balls.splice(freeBallIndex, 1);
        } else {
            break;
        }
    }
}

// 毎フレームの更新処理（1秒間に60回）
setInterval(() => {
    if (finalWinner) return;
    // ★ 試合中（playing）のときだけボールや勝敗のロジックを動かす
    if (gameState !== 'playing') {
        // 現在の状態を毎フレーム同期（ポーズ中などの画面表示のため）
        io.emit('gameUpdate', { balls, players, scores, finalWinner, gameState });
        return;
    }

    const now = Date.now();

    balls.forEach(ball => {
        if (ball.owner === "free") {
            ball.x += ball.dx;
            ball.y += ball.dy;

            if (ball.x - ball.radius < 0 || ball.x + ball.radius > 1000) {
                ball.dx *= -1;
                ball.lastOwnerTeam = null;
                ball.lastThrowerId = null;
            }
            if (ball.y - ball.radius < 0 || ball.y + ball.radius > 400) {
                ball.dy *= -1;
                ball.lastOwnerTeam = null;
                ball.lastThrowerId = null;
            }

            for (let id in players) {
                let p = players[id];
                if (p.isOutfield || p.isSpectator) continue; // ★ 観戦者には当たらない
                
                if (ball.lastOwnerTeam === null || ball.lastOwnerTeam === p.team) continue;

                if (ball.x > p.x - ball.radius && ball.x < p.x + 30 + ball.radius &&
                    ball.y > p.y - ball.radius && ball.y < p.y + 30 + ball.radius) {
                    
                    p.isOutfield = true;
                    p.x = p.team === 'blue' ? Math.random() * 100 + 880 : Math.random() * 100 + 20;
                    p.y = Math.random() * 300 + 50;
                    io.to(id).emit('youAreOut');

                    if (ball.lastThrowerId) {
                        const thrower = players[ball.lastThrowerId];
                        if (thrower && thrower.isOutfield) {
                            thrower.isOutfield = false;
                            thrower.x = thrower.team === 'blue' ? Math.random() * 250 + 200 : Math.random() * 250 + 550;
                            thrower.y = Math.random() * 300 + 50;
                            console.log(`[復活] 外野の ${thrower.name} が敵を仕留めて内野に復帰しました！`);
                        }
                    }

                    ball.lastOwnerTeam = null;
                    ball.lastThrowerId = null;
                    
                    io.emit('playerUpdate', players);
                }
            }
        } else {
            const ownerPlayer = players[ball.owner];
            if (ownerPlayer) {
                if (ball.holdStartTime && (now - ball.holdStartTime > 5000)) {
                    ball.owner = "free";
                    ball.lastOwnerTeam = null;
                    ball.lastThrowerId = null;
                    ball.holdStartTime = null;
                    ball.dx = (Math.random() - 0.5) * 2;
                    ball.dy = 2; 
                    console.log(`[時間切れ] 5秒経過したため強制リリース。`);
                } else {
                    ball.x = ownerPlayer.x + 15;
                    ball.y = ownerPlayer.y - ball.radius + 5;
                }
            } else {
                ball.owner = "free";
                ball.lastOwnerTeam = null;
                ball.lastThrowerId = null;
                ball.holdStartTime = null;
            }
        }
    });

    const activePlayers = Object.values(players).filter(p => !p.isSpectator);
    const blueInside = activePlayers.filter(p => p.team === 'blue' && !p.isOutfield).length;
    const redInside = activePlayers.filter(p => p.team === 'red' && !p.isOutfield).length;
    
    const blueTotal = activePlayers.filter(p => p.team === 'blue').length;
    const redTotal = activePlayers.filter(p => p.team === 'red').length;

    if (blueTotal > 0 && redTotal > 0) {
        let roundOver = false;
        let winnerTeam = "";

        if (blueInside === 0) {
            scores.red++;
            winnerTeam = '紅（RED）';
            roundOver = true;
        } else if (redInside === 0) {
            scores.blue++;
            winnerTeam = '蒼（BLUE）';
            roundOver = true;
        }

        if (roundOver) {
            if (scores.blue >= 8) {
                finalWinner = "青チーム (BLUE TEAM)";
                gameState = 'waiting'; // 試合終了したら待機画面へ
                io.emit('finalMatchOver', { finalWinner, scores });
            } else if (scores.red >= 8) {
                finalWinner = "赤チーム (RED TEAM)";
                gameState = 'waiting';
                io.emit('finalMatchOver', { finalWinner, scores });
            } else {
                io.emit('matchOver', { winnerTeam, scores });
                resetRound();
            }
        }
    }

    io.emit('gameUpdate', { balls, players, scores, finalWinner, gameState });
}, 1000 / 60);

function resetRound() {
    for (let id in players) {
        if (players[id].isSpectator) continue;
        players[id].isOutfield = false;
        if (players[id].team === 'blue') {
            players[id].x = Math.random() * 250 + 200;
        } else {
            players[id].x = Math.random() * 250 + 550;
        }
        players[id].y = Math.random() * 300 + 50;
    }
    balls = [];
    adjustBallCount();
}

function fullResetGame() {
    scores = { blue: 0, red: 0 };
    finalWinner = null;
    gameState = 'waiting';
    // リセット時は全員観戦を解除して再度プレイヤーに戻す
    for (let id in players) {
        players[id].isSpectator = false;
        players[id].isOutfield = false;
    }
    resetRound();
    io.emit('adminResetNotify');
}

io.on('connection', (socket) => {
    // ★ 試合がすでに始まっている（playing または paused）場合は「観戦者」として登録
    const shouldSpectate = (gameState === 'playing' || gameState === 'paused');

    const team = assignTeam();
    const pName = (shouldSpectate ? "観戦_" : (team === 'blue' ? "青_" : "赤_")) + Math.floor(Math.random() * 90 + 10);
    // 観戦者は画面外（見えない場所）に配置
    const spawnX = shouldSpectate ? -999 : (team === 'blue' ? Math.random() * 250 + 200 : Math.random() * 250 + 550);

    players[socket.id] = {
        id: socket.id,
        name: pName,
        team: team,
        x: spawnX,
        y: shouldSpectate ? -999 : Math.random() * 300 + 50,
        isOutfield: false,
        isSpectator: shouldSpectate // ★ 観戦モードフラグ
    };

    if (!shouldSpectate) {
        adjustBallCount();
    }
    
    socket.emit('init', { myId: socket.id, players, balls, scores, finalWinner, gameState });

    socket.on('move', (data) => {
        const p = players[socket.id];
        // ★ 試合中かつ観戦者でない場合のみ移動を許可
        if (p && gameState === 'playing' && !p.isSpectator && !finalWinner) {
            let targetX = data.x;
            let targetY = data.y;

            if (!p.isOutfield) {
                if (p.team === 'blue') {
                    if (targetX < 150) targetX = 150;
                    if (targetX > 500 - 30) targetX = 500 - 30;
                } else {
                    if (targetX < 500) targetX = 500;
                    if (targetX > 850 - 30) targetX = 850 - 30;
                }
            } else {
                if (p.team === 'blue') {
                    if (targetX < 850) targetX = 850;
                    if (targetX > 1000 - 30) targetX = 1000 - 30;
                } else {
                    if (targetX < 0) targetX = 0;
                    if (targetX > 150 - 30) targetX = 150 - 30;
                }
            }
            p.x = targetX;
            p.y = targetY;
        }
    });

    socket.on('ballAction', (data) => {
        if (gameState !== 'playing' || finalWinner) return;
        const p = players[socket.id];
        if (!p || p.isSpectator) return; // 観戦者はボールを触れない

        const targetBall = balls.find(b => b.id === data.ballId);
        if (!targetBall) return;

        if (data.action === "catch" && targetBall.owner === "free") {
            const alreadyHolding = balls.some(b => b.owner === socket.id);
            if (!alreadyHolding) {
                targetBall.owner = socket.id;
                targetBall.dx = 0;
                targetBall.dy = 0;
                targetBall.lastOwnerTeam = null;
                targetBall.lastThrowerId = null;
                targetBall.holdStartTime = Date.now();
            }
        } else if (data.action === "throw" && targetBall.owner === socket.id) {
            targetBall.owner = "free";
            targetBall.lastOwnerTeam = p.team;
            targetBall.lastThrowerId = socket.id;
            targetBall.dx = data.dx;
            targetBall.dy = data.dy;
            targetBall.holdStartTime = null;
        }
    });

    // ★ 管理者用コマンド制御
    socket.on('adminControl', (data) => {
        const correctPassword = "Sasd1213";
        if (!data || data.password !== correctPassword) {
            socket.emit('adminAuthFailed');
            return;
        }

        if (data.command === 'start') {
            gameState = 'playing';
            console.log(" [管理者] ゲームが開始されました");
        } else if (data.command === 'pause') {
            gameState = 'paused';
            console.log(" [管理者] ゲームが一時中断されました");
        } else if (data.command === 'reset') {
            fullResetGame();
            console.log(" [管理者] ゲームが初期化されました");
        }
    });

    socket.on('disconnect', () => {
        delete players[socket.id];
        balls = balls.filter(b => b.owner !== socket.id);
        adjustBallCount();
        io.emit('gameUpdate', { balls, players, scores, finalWinner, gameState });
    });
});

server.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));